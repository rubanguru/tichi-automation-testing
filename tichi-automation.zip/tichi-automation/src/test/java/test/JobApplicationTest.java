package test;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import base.BaseTest;

public class JobApplicationTest extends BaseTest {

	@Test
	public void openIndividualServices() {

	    WebElement service = driver.findElement(By.xpath("//h3[contains(text(),'Individual Services')]"));

	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", service);

	    service.click();

	    System.out.println("Individual Services section clicked successfully");

	}
    }
